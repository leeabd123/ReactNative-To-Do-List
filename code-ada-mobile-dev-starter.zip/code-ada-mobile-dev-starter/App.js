import * as React from 'react';
import { Text, View, StyleSheet, TextInput, SafeAreaView } from 'react-native';
import Constants from 'expo-constants';
import ButtonExample from './components/ButtonExample';
import { Ionicons } from '@expo/vector-icons';

const UselessTextInput = () => {
  const [text, onChangeText] = React.useState("Useless Text");
  const [number, onChangeNumber] = React.useState(null);

  return (
    <SafeAreaView>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={text}
      />
      <TextInput
        style={styles.input}
        onChangeText={onChangeNumber}
        value={number}
        placeholder="useless placeholder"
        keyboardType="numeric"
      />
    </SafeAreaView>
  );
};

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       Leena's To Do List
      </Text>
      <ButtonExample onPress={() => console.log('Pressed!')
      }>
      <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="white" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
          <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="black" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="white" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="black" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="white" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="black" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="white" />
        <Text> </Text>
      </ButtonExample>
      <ButtonExample onPress={() => 
      console.log('Pressed!')}>
        <TextInput />
        <Ionicons name="md-checkmark-circle" size={32} color="black" />
        <Text> </Text>
      </ButtonExample>
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
