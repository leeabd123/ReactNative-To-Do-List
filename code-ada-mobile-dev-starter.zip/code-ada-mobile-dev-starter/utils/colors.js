const COLORS = {
  WCSPink: '#e36166',
  WCSBlue: '#66cccc',
};

export default COLORS;