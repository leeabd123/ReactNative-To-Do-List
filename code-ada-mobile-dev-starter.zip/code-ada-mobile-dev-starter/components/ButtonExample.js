import * as React from 'react';
import { Text, View, StyleSheet, Image, Pressable } from 'react-native';
import COLORS from '../utils/colors';

export default function ButtonExample({ onPress, children }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ([
        styles.container,
        {backgroundColor: pressed ? COLORS.WCSBlue: COLORS.WCSPink}
      ])}
    >
      {children}
    </Pressable>
  );
}


const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'right',
    justifyContent: 'right',
    padding: 24,
    borderRadius: 10,
  },
});
